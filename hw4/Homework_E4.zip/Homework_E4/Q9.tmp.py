header_1 = "ABC123"
seq_1 = "ATCGYACGATCGATCGATCGCYAGACGTATCG"

header_2 = "DEF456"
seq_2 = "actgatogacgatogatcgaycacgact"

header_3 = "HIJ789"
seq_3 = "ACTGAC-ACTGT--AOTGTA----CATGTG"
